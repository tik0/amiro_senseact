#! /bin/sh

# Installs all available packages from cvb

DIR=$(cd $(dirname "$0"); pwd)

sudo apt-get -y install libwxgtk2.8-0
find "$DIR" -name "*codemeter*deb" -print0 | xargs -0 sudo dpkg -i
find "$DIR" -name "*genicam*deb" -print0 | xargs -0 sudo dpkg -i 
find "$DIR" -name "*cvb*deb" -print0 | xargs -0 sudo dpkg -i 

echo Reboot required!
