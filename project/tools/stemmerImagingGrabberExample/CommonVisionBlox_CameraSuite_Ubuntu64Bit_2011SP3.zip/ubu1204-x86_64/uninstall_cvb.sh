#! /bin/sh

# Uninstalls all available packages from cvb

sudo apt-get remove cvb_camerasuite-dev
sudo apt-get remove cvb_camerasuite
sudo apt-get remove genicam
sudo apt-get remove codemeter64

echo ""
echo Reboot required!
